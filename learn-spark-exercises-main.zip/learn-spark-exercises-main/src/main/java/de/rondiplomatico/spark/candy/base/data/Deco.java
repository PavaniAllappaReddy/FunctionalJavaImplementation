package de.rondiplomatico.spark.candy.base.data;

/**
 * @author wirtzd
 * @since 11.05.2021
 */
public enum Deco {

    PLAIN,
    HSTRIPES,
    VSTRIPES,
    WRAPPED;
}
