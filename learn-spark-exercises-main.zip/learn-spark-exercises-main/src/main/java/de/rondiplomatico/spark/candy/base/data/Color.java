package de.rondiplomatico.spark.candy.base.data;

import java.io.Serializable;

public enum Color {

    RED,
    PURPLE,
    ORANGE,
    YELLOW,
    BLUE,
    GREEN;
}
